"""OpenPIV skill scripts."""
